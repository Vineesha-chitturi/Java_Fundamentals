class Pgm3{  
    public static void main(String [] args){  
int num1=Integer.parseInt(args[0]);
int num2=Integer.parseInt(args[1]);
int sum=num1+num2;
     System.out.println("The sum of"+" "+args[0]+" "+"and"+" "+args[1]+" is "+sum);  
    }  
}  