class Pgm2{  
    public static void main(String [] args){  
     System.out.println("Welcome"+" "+args[0]);  
    }  
}  