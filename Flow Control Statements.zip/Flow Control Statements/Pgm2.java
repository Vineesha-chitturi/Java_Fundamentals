class Pgm2
{
public static void main(String args[])
{
int num;
num=Integer.parseInt(args[0]);
if(num%2==0)
{
System.out.println("even");
}
else
{
System.out.println("odd");
}
}
}