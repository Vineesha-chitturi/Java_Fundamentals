class Pgm18
{
public static void main(String args[])
{
int num=Integer.parseInt(args[0]);
int num1=num;
int r;
int sum=0;
while(num!=0)
{
r=num%10;
sum=sum*10+r;
num=num/10;
}
if(sum==num1)
{
System.out.println(num1+" is a palindrome");
}
else
{
System.out.println(num1+" is not a palindrome");
}
}
}