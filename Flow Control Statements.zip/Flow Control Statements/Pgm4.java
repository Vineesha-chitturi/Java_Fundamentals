import java.util.Scanner;
class Pgm4
{
public static void main(String args[])
{
Scanner s = new Scanner ( System .in);
char a1=s.next().charAt(0);
char a2=s.next().charAt(0);
if(a1>a2)
{
System.out.print(a2+","+a1);
}
else
{System.out.print(a1+","+a2);}
}
}