class Pgm3
{
public static void main(String args[])
{
int l=args.length;
int i;
if(l==0)
{
System.out.println("No Values");
}
else
{
for(String name:args)
{
System.out.print(name +" ");
}
}
}}
