import java.util.Scanner;
class Pgm7
{
public static void main(String args[])
{
Scanner s = new Scanner ( System .in);
char c=s.next().charAt(0);
if(Character.isUpperCase(c))
{System.out.println(Character.toLowerCase(c));}
if(Character.isLowerCase(c))
{System.out.println(Character.toUpperCase(c));}
}
}