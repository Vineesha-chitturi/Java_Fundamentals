class Pgm19
{
public static void main(String args[])
{
int i;
for(i=1;i<=10;i++)
{
System.out.println(5*3*2*i);
}
}
}