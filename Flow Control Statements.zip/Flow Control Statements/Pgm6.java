class Pgm6
{
public static void main(String args[])
{
String Gen=args[0];
int age=Integer.parseInt(args[1]);
if(Gen.equals("Female"))
{
if(age>=1&&age<=58)
{System.out.println("8.2%");}
if(age>=59&&age<=100)
{System.out.println("9.2%");}
}
if(Gen.equals("Male"))
{
if(age>=1&&age<=58)
{System.out.println("8.4%");}
if(age>=59&&age<=100)
{System.out.println("10.5%");}
}
}
}