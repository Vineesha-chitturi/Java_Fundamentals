class Pgm12
{
public static void main(String args[])
{
int num=Integer.parseInt(args[0]);
int count=0;
int i;
for(i=1;i<=num;i++)
{
if(num%i==0)
{count=count+1;}
}
if(count==2)
{System.out.println("Given number is prime number");}
else
{System.out.println("Given number is not a prime number");}
}
}