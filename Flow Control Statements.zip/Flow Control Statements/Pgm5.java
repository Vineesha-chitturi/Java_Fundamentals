import java.util.Scanner;
class Pgm5
{
    public static void main (String[] args)
    {
       Scanner s = new Scanner ( System .in);
        char a1=s.next().charAt(0);
         if((a1>96&&a1<123)||(a1>64&&a1<91))
            System.out.println("Alphabet");
        else if(a1>47&&a1<58)
            System.out.println("Digit");
        else
            System.out.println("Special Character");
    }
    }
