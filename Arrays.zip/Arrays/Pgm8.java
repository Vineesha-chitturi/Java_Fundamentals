import java.util.Scanner;
class Pgm8
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
int size=s.nextInt();
int[] arr=new int[size];
for(int i=0;i<size;i++)
{arr[i]=s.nextInt();}
int a=6;
int b=7;
int i,j;
int total=0;
boolean add=true;
for(i=0;i<size;i++)
{
if(arr[i]!=a && add==true){
total+=arr[i];}
else if(arr[i]==a)
add=false;
else if(arr[i]==b)
add=true;
}
System.out.println(total);
}}