import java.util.Scanner;
class Pgm1
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
int size=s.nextInt();
int[] arr=new int[size];
for(int i=0;i<size;i++)
{arr[i]=s.nextInt();}
int total=0;
for(int i=0;i<size;i++)
{total+=arr[i];}
System.out.println("Sum of the array is :"+total);
int avg;
avg=(total/arr.length);
System.out.println("Average of the array is :"+avg);
}
}