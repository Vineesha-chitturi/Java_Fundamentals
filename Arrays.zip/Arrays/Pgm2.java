import java.util.Scanner;
class Pgm2
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
int size=s.nextInt();
int[] arr=new int[size];
for(int i=0;i<size;i++)
{arr[i]=s.nextInt();}
int min=arr[0];
int max=arr[0];
for(int i=0;i<size;i++)
{
if(arr[i]<=min)
{min=arr[i];}
if(arr[i]>=max)
{max=arr[i];}
}
System.out.println("Minimum element of the array is :"+min);
System.out.println("Maximum element of the array is :"+max);
}
}