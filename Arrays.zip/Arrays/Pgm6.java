import java.util.Scanner;
import java.util.Arrays;
class Pgm6
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
int size=s.nextInt();
int[] arr=new int[size];
for(int i=0;i<size;i++)
{arr[i]=s.nextInt();}
Arrays.sort(arr);
for(int ele:arr)
{System.out.print(ele+" ");}
}
}