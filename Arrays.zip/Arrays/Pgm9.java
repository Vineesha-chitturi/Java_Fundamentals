class Pgm9 
{
public static void main(String[] args) 
{
if (args.length != 4)
System.out.println("Please enter 4 integer numbers");
else {
int arr[][] = new int[2][2];
for (int i = 0, k = 0; i < 2; i++) {
for (int j = 0; j < 2; j++, k++) {
arr[i][j] = Integer.parseInt(args[k]);
}
}
System.out.println("The given array is :");
for (int i = 0; i < 2; i++) {
for (int j = 0; j < 2; j++) {
System.out.print(arr[i][j] + " ");
 }
System.out.println();
}
for (int i = 0; i < 2; i++) 
{
int tmp = arr[0][i];
arr[0][i] = arr[1][i];
arr[1][i] = tmp;
}
for (int i = 0; i < 2; i++) 
{
int tmp = arr[i][0];
arr[i][0] = arr[i][1];
arr[i][1] = tmp;
}
System.out.println("The reverse of the array is :");
for (int i = 0; i < 2; i++)
 {
for (int j = 0; j < 2; j++) 
{
System.out.print(arr[i][j] + " ");
}
System.out.println();
}
}
}
}