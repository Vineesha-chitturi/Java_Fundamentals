import java.util.Scanner;
class Pgm7
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
int n=s.nextInt();
int[] a=new int[n];
for(int i=0;i<n;i++)
{a[i]=s.nextInt();}
for (int i = 0; i < n; i++)
{
boolean flag = false;
for (int j = 0; j < i; j++)
{
if(a[i] == a[j]) 
{
flag = true;
}
}
if (flag)
{
for (int j = i; j <n; j++) {
a[i] = a[i+1];
}
n--;
}
}
for (int i = 0; i < n; i++) 
{
System.out.print(a[i] + " ");
}
System.out.println();
}}