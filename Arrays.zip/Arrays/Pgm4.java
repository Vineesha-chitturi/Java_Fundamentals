class Pgm4
{
public static void main(String args[]){
int num[] = {33,48,65,87,97,116};
String str =null;
for(int i: num){
str = Character.toString((char)i);
System.out.print(str+" ");
}
}
}