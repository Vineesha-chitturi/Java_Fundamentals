import java.util.Scanner;
import java.util.Arrays;
class Pgm5
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
int size=s.nextInt();
int[] arr=new int[size];
for(int i=0;i<size;i++)
{arr[i]=s.nextInt();}
Arrays.sort(arr);
System.out.print("first two largest elements:"+arr[size-1]+" "+arr[size-2]);
System.out.println();
System.out.print("first two smallest elements:"+arr[0]+" "+arr[1]);
}
}