import java.util.Scanner;
class Pgm3
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
int size=s.nextInt();
int[] arr=new int[size];
for(int i=0;i<size;i++)
{arr[i]=s.nextInt();}
int key=s.nextInt();
int pos=-1;
for(int i=0;i<size;i++)
{
if(arr[i]==key)
pos=i;
}
System.out.println(pos);
}
}